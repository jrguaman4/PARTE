#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Genera data/personal.json desde un CSV de base.
Uso:  python tools/csv_to_json.py base.csv
El CSV puede venir en ISO-8859-1 (Latin1) o UTF-8.
Columnas esperadas:
  CEDULA, GRADO, NOMBRES, DEPENDENCIAS, CARGO/FUNCION,
  "NOVEDADES, ALERTAS,", GRUPO, ESTADO, CELULAR
"""
import csv, json, sys, os

def detectar_encoding(path):
    for enc in ('utf-8-sig', 'utf-8', 'latin-1'):
        try:
            with open(path, encoding=enc) as f:
                f.read()
            return enc
        except UnicodeDecodeError:
            continue
    return 'latin-1'

def main():
    src = sys.argv[1] if len(sys.argv) > 1 else 'base.csv'
    enc = detectar_encoding(src)
    with open(src, encoding=enc, newline='') as f:
        rows = list(csv.reader(f))
    out = []
    for i, row in enumerate(rows[1:]):
        row = row + [''] * (9 - len(row)) if len(row) < 9 else row
        if not row[0].strip():
            continue
        out.append({
            'id': i + 1,
            'cedula': row[0].strip(), 'grado': row[1].strip(),
            'nombres': row[2].strip(), 'dependencia': row[3].strip(),
            'funcion': row[4].strip(), 'novedades': row[5].strip(),
            'grupo': row[6].strip(), 'estado': row[7].strip(),
            'celular': row[8].strip(),
        })
    os.makedirs('data', exist_ok=True)
    with open('data/personal.json', 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    print(f'OK · {len(out)} registros -> data/personal.json (origen {enc})')

if __name__ == '__main__':
    main()
