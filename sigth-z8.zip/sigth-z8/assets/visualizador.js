/* ===== Visualizador Parte General ===== */
let DATA = [], FILTRADO = [], PAGE = 1, PER = 25, chE, chD;

document.addEventListener('DOMContentLoaded', async () => {
  document.getElementById('fecha').value = DataStore.hoy();
  await DataStore.init();
  poblarFiltros();
  recargar();
  document.getElementById('fecha').addEventListener('change', recargar);
  document.getElementById('f-q').addEventListener('input', () => { PAGE=1; render(); });
});

function recargar(){
  const f = document.getElementById('fecha').value || DataStore.hoy();
  DATA = DataStore.getParte(f);
  render();
  kpis();
  charts();
}

function poblarFiltros(){
  const dep = document.getElementById('f-dep');
  dep.innerHTML = '<option value="">Todas</option>' + DataStore.listaDependencias().map(d=>`<option>${esc(d)}</option>`).join('');
  document.getElementById('f-est').innerHTML = '<option value="">Todos</option>' + ESTADOS.map(e=>`<option>${e}</option>`).join('');
  document.getElementById('f-gru').innerHTML = '<option value="">Todos</option>' + GRUPOS.map(g=>`<option>${g}</option>`).join('');
  ['f-dep','f-est','f-gru'].forEach(id=>document.getElementById(id).addEventListener('change',()=>{PAGE=1;render();}));
}

function aplicarFiltros(){
  const q=(document.getElementById('f-q').value||'').toLowerCase().trim();
  const d=document.getElementById('f-dep').value, e=document.getElementById('f-est').value, g=document.getElementById('f-gru').value;
  return DATA.filter(p=>{
    if(q && !(`${p.cedula} ${p.nombres}`.toLowerCase().includes(q))) return false;
    if(d && p.dependencia!==d) return false;
    if(e && (p.estado||'').toUpperCase()!==e) return false;
    if(g && p.grupo!==g) return false;
    return true;
  });
}

function render(){
  FILTRADO = aplicarFiltros();
  const total = FILTRADO.length, pages = Math.max(1,Math.ceil(total/PER));
  if(PAGE>pages) PAGE=pages;
  const slice = FILTRADO.slice((PAGE-1)*PER, PAGE*PER);
  document.getElementById('tbody').innerHTML = slice.map((p,i)=>`
    <tr>
      <td>${(PAGE-1)*PER+i+1}</td>
      <td>${esc(p.cedula)}</td><td>${esc(p.grado)}</td><td>${esc(p.nombres)}</td>
      <td>${esc(p.dependencia)}</td><td>${esc(p.funcion)}</td>
      <td>${esc(p.novedades)||'—'}</td><td>${esc(p.grupo)}</td><td>${badgeEstado(p.estado)}</td>
    </tr>`).join('') || '<tr><td colspan="9" class="text-center py-4" style="color:var(--muted)">Sin resultados</td></tr>';
  document.getElementById('count').textContent = `${total} servidores`;
  // pager
  let h='';
  for(let i=1;i<=pages;i++){ if(i===1||i===pages||Math.abs(i-PAGE)<=1){h+=`<button class="btn btn-sm ${i===PAGE?'btn-gold':'btn-ghost'}" onclick="PAGE=${i};render()">${i}</button>`;}else if(Math.abs(i-PAGE)===2){h+='<span class="px-1" style="color:var(--muted)">…</span>';}}
  document.getElementById('pager').innerHTML = h;
  document.getElementById('rep-fecha').textContent = 'Fecha: ' + (document.getElementById('fecha').value||DataStore.hoy());
}

function limpiar(){ ['f-q','f-dep','f-est','f-gru'].forEach(id=>document.getElementById(id).value=''); PAGE=1; render(); }

function kpis(){
  const t=DATA.length;
  const pres=DATA.filter(p=>(p.estado||'').toUpperCase().includes('PRESENTE')).length;
  const fr=DATA.filter(p=>(p.estado||'').toUpperCase().includes('FRANCO')).length;
  document.getElementById('k-total').textContent=t;
  document.getElementById('k-pres').textContent=pres;
  document.getElementById('k-franco').textContent=fr;
  document.getElementById('k-aus').textContent=t-pres-fr;
  document.getElementById('k-dep').textContent=DataStore.listaDependencias().length;
  document.getElementById('k-val').textContent=DataStore.dependenciasValidadas(document.getElementById('fecha').value).length;
}

function charts(){
  const byEst={}, byDep={};
  DATA.forEach(p=>{ const e=(p.estado||'SIN DATO').toUpperCase(); byEst[e]=(byEst[e]||0)+1; byDep[p.dependencia]=(byDep[p.dependencia]||0)+1; });
  const gold=['#d4af37','#19c37d','#5b8def','#e0455a','#f0d772','#9fb2d8','#7b61ff','#ff9f43','#2dd4bf','#c084fc'];
  if(chE)chE.destroy(); if(chD)chD.destroy();
  chE=new Chart(document.getElementById('chEstado'),{type:'doughnut',
    data:{labels:Object.keys(byEst),datasets:[{data:Object.values(byEst),backgroundColor:gold,borderColor:'#001b4a',borderWidth:2}]},
    options:{plugins:{legend:{labels:{color:'#e9eefb',font:{size:11}}}}}});
  const depE=Object.entries(byDep).sort((a,b)=>b[1]-a[1]);
  chD=new Chart(document.getElementById('chDep'),{type:'bar',
    data:{labels:depE.map(d=>d[0]),datasets:[{data:depE.map(d=>d[1]),backgroundColor:'#d4af37'}]},
    options:{indexAxis:'y',plugins:{legend:{display:false}},scales:{x:{ticks:{color:'#9fb2d8'},grid:{color:'rgba(255,255,255,.05)'}},y:{ticks:{color:'#e9eefb',font:{size:10}},grid:{display:false}}}}});
}

function guardarDia(){
  const f=document.getElementById('fecha').value||DataStore.hoy();
  DataStore.guardarParteCompleto(DATA,f);
  Swal.fire({icon:'success',title:'Parte guardado',text:`Snapshot del ${f} respaldado correctamente`,
    background:'#012a6b',color:'#fff',confirmButtonColor:'#d4af37'});
}

function imprimirReporte(){
  Swal.fire({
    title:'Reporte de Parte General',
    html:'<input id="resp" class="swal2-input" placeholder="Nombre del responsable">',
    background:'#012a6b',color:'#fff',confirmButtonColor:'#d4af37',
    showCancelButton:true, confirmButtonText:'<i class="bi bi-printer"></i> Imprimir',
    cancelButtonText:'Exportar PDF', cancelButtonColor:'#19c37d',
    preConfirm:()=>document.getElementById('resp').value||'(sin responsable)'
  }).then(r=>{
    const resp = (r.value)||(r.dismiss==='cancel'?(document.getElementById('resp')?.value||'(sin responsable)'):null);
    if(r.isConfirmed){
      const el=document.getElementById('rep-resp');
      el.style.display='block'; el.textContent='Responsable: '+r.value;
      setTimeout(()=>{window.print(); el.style.display='none';},150);
    } else if(r.dismiss==='cancel'){
      exportarPDF(resp);
    }
  });
}

function exportarPDF(resp){
  const {jsPDF}=window.jspdf; const doc=new jsPDF('l','mm','a4');
  const f=document.getElementById('fecha').value||DataStore.hoy();
  doc.setFillColor(0,27,74); doc.rect(0,0,297,22,'F');
  doc.setTextColor(212,175,55); doc.setFontSize(14);
  doc.text('PARTE POLICIAL GENERAL · TALENTO HUMANO ZONA 8',14,10);
  doc.setTextColor(255,255,255); doc.setFontSize(9);
  doc.text(`Fecha: ${f}   |   Responsable: ${resp||'(sin responsable)'}   |   Total: ${FILTRADO.length}`,14,17);
  doc.autoTable({
    startY:26,
    head:[['Cédula','Grado','Nombres','Dependencia','Función','Novedades','Gr','Estado']],
    body:FILTRADO.map(p=>[p.cedula,p.grado,p.nombres,p.dependencia,p.funcion,p.novedades,p.grupo,p.estado]),
    styles:{fontSize:6.5,cellPadding:1.2},
    headStyles:{fillColor:[1,42,107],textColor:[212,175,55]},
    alternateRowStyles:{fillColor:[240,243,250]}
  });
  doc.save(`Parte_General_Z8_${f}.pdf`);
}
