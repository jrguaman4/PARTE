/* =========================================================
   SIGTH-Z8 · Capa de datos (data layer)
   - Carga datos base desde data/personal.json (datos SEPARADOS del código)
   - Persiste el parte de cada día en localStorage por fecha
   - No expone datos sensibles dentro del HTML/JS de la app
   ========================================================= */
const DataStore = (() => {
  const STORAGE_PREFIX = 'sigth_z8_parte_';      // + YYYY-MM-DD
  const VALID_PREFIX   = 'sigth_z8_validadas_';   // dependencias validadas por fecha
  const CAMPOS_EDIT    = ['funcion','novedades','grupo','estado'];

  let _base = [];   // datos base inmutables
  let _ready = null;

  function hoy(){ return new Date().toISOString().slice(0,10); }

  async function init(){
    if(_ready) return _ready;
    _ready = fetch('data/personal.json', {cache:'no-store'})
      .then(r => { if(!r.ok) throw new Error('No se pudo cargar la base'); return r.json(); })
      .then(j => { _base = j; return j; });
    return _ready;
  }

  /* Devuelve el parte del día: base fusionada con cambios guardados */
  function getParte(fecha = hoy()){
    const saved = JSON.parse(localStorage.getItem(STORAGE_PREFIX + fecha) || '{}');
    return _base.map(p => {
      const ov = saved[p.id] || {};
      return {...p, ...ov};
    });
  }

  /* Guarda los cambios de UNA dependencia para una fecha */
  function guardarDependencia(dep, registros, fecha = hoy()){
    const key = STORAGE_PREFIX + fecha;
    const saved = JSON.parse(localStorage.getItem(key) || '{}');
    registros.forEach(r => {
      const ov = {};
      CAMPOS_EDIT.forEach(c => ov[c] = r[c]);
      saved[r.id] = {...(saved[r.id]||{}), ...ov};
    });
    localStorage.setItem(key, JSON.stringify(saved));
    // marcar dependencia como validada
    const vkey = VALID_PREFIX + fecha;
    const val = JSON.parse(localStorage.getItem(vkey) || '[]');
    if(!val.includes(dep)){ val.push(dep); localStorage.setItem(vkey, JSON.stringify(val)); }
  }

  /* Guarda TODO el parte general (snapshot del día) */
  function guardarParteCompleto(registros, fecha = hoy()){
    const key = STORAGE_PREFIX + fecha;
    const saved = {};
    registros.forEach(r => {
      const ov = {};
      CAMPOS_EDIT.forEach(c => ov[c] = r[c]);
      saved[r.id] = ov;
    });
    localStorage.setItem(key, JSON.stringify(saved));
  }

  function dependenciasValidadas(fecha = hoy()){
    return JSON.parse(localStorage.getItem(VALID_PREFIX + fecha) || '[]');
  }

  function fechasGuardadas(){
    const out = [];
    for(let i=0;i<localStorage.length;i++){
      const k = localStorage.key(i);
      if(k && k.startsWith(STORAGE_PREFIX)) out.push(k.replace(STORAGE_PREFIX,''));
    }
    return out.sort().reverse();
  }

  function listaDependencias(){
    return [...new Set(_base.map(p => p.dependencia))].sort();
  }

  function base(){ return _base; }

  return { init, hoy, getParte, guardarDependencia, guardarParteCompleto,
           dependenciasValidadas, fechasGuardadas, listaDependencias, base, CAMPOS_EDIT };
})();

/* Utilidades compartidas */
const ESTADOS = ['PRESENTE','FRANCO','VACACIONES','LICENCIA','SERVICIO','COMISION',
  'PERMISO','DESCANSO MEDICO','TRASLADO TEMPORAL','TRASLADO OCASIONAL','PASE','CESE','PCIC'];
const GRUPOS = ['1','2','3'];

function badgeEstado(e){
  const u = (e||'').toUpperCase();
  let cls = 'e-otro';
  if(u.includes('PRESENTE')) cls='e-presente';
  else if(u.includes('FRANCO')) cls='e-franco';
  else if(u.includes('VACAC')||u.includes('LICEN')||u.includes('CESE')||u.includes('MEDIC')) cls='e-vac';
  return `<span class="badge-estado ${cls}">${e||'—'}</span>`;
}
function esc(s){ return (s??'').toString().replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
