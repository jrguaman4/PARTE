/* ===== Ingreso Parte por Dependencias ===== */
let DEP_ACTUAL = null, REGS = [];

document.addEventListener('DOMContentLoaded', async () => {
  document.getElementById('fecha').value = DataStore.hoy();
  await DataStore.init();
  pintarGrid();
  document.getElementById('fecha').addEventListener('change', () => {
    if(DEP_ACTUAL) abrirDep(DEP_ACTUAL); else pintarGrid();
  });
});

function fecha(){ return document.getElementById('fecha').value || DataStore.hoy(); }

function pintarGrid(){
  const parte = DataStore.getParte(fecha());
  const validadas = DataStore.dependenciasValidadas(fecha());
  const deps = DataStore.listaDependencias();
  const grid = document.getElementById('depGrid');
  grid.innerHTML = deps.map(d=>{
    const n = parte.filter(p=>p.dependencia===d).length;
    const done = validadas.includes(d);
    return `<div class="dep-card glass-card ${done?'done':'pending'}" onclick="abrirDep('${d.replace(/'/g,"\\'")}')">
      <span class="tag">${done?'Validada':'Pendiente'}</span>
      <div class="name">${esc(d)}</div>
      <div class="meta"><span><i class="bi bi-people"></i> ${n} servidores</span>
      <span>${done?'<i class="bi bi-check-circle-fill"></i>':'<i class="bi bi-exclamation-circle"></i>'}</span></div>
    </div>`;
  }).join('');
}

function abrirDep(dep){
  DEP_ACTUAL = dep;
  REGS = DataStore.getParte(fecha()).filter(p=>p.dependencia===dep);
  document.getElementById('depTitle').textContent = dep;
  const optEst = e => ESTADOS.map(x=>`<option ${(e||'').toUpperCase()===x?'selected':''}>${x}</option>`).join('');
  const optGru = g => GRUPOS.map(x=>`<option ${g===x?'selected':''}>${x}</option>`).join('');
  document.getElementById('editBody').innerHTML = REGS.map((p,i)=>`
    <tr>
      <td>${esc(p.grado)}</td>
      <td>${esc(p.nombres)}<br><small style="color:var(--muted)">${esc(p.cedula)} · ${esc(p.celular)}</small></td>
      <td><input class="form-control form-control-sm" data-i="${i}" data-c="funcion" value="${esc(p.funcion)}"></td>
      <td><textarea class="form-control form-control-sm" rows="1" data-i="${i}" data-c="novedades">${esc(p.novedades)}</textarea></td>
      <td><select class="form-select form-select-sm" data-i="${i}" data-c="grupo" style="min-width:70px"><option value="">—</option>${optGru(p.grupo)}</select></td>
      <td><select class="form-select form-select-sm" data-i="${i}" data-c="estado" style="min-width:140px">${optEst(p.estado)}</select></td>
    </tr>`).join('');
  document.getElementById('vista-grid').style.display='none';
  document.getElementById('vista-edit').style.display='block';
  document.getElementById('btnBack').style.display='inline-block';
}

function verGrid(){
  DEP_ACTUAL=null;
  document.getElementById('vista-edit').style.display='none';
  document.getElementById('vista-grid').style.display='block';
  document.getElementById('btnBack').style.display='none';
  pintarGrid();
}

function leerEdiciones(){
  document.querySelectorAll('#editBody [data-i]').forEach(el=>{
    REGS[+el.dataset.i][el.dataset.c] = el.value;
  });
}

function guardarDep(){
  leerEdiciones();
  DataStore.guardarDependencia(DEP_ACTUAL, REGS, fecha());
  Swal.fire({icon:'success',title:'Parte guardado',
    text:`${DEP_ACTUAL} validada para el ${fecha()}`,
    background:'#012a6b',color:'#fff',confirmButtonColor:'#d4af37'})
    .then(()=>verGrid());
}

function exportarUnidadPDF(){
  leerEdiciones();
  Swal.fire({
    title:'Reporte de Unidad Validada',
    html:'<input id="resp" class="swal2-input" placeholder="Nombre del responsable">',
    background:'#012a6b',color:'#fff',confirmButtonColor:'#d4af37',
    showCancelButton:true, confirmButtonText:'<i class="bi bi-file-earmark-pdf"></i> Generar PDF',
    preConfirm:()=>document.getElementById('resp').value||'(sin responsable)'
  }).then(r=>{
    if(!r.isConfirmed) return;
    const {jsPDF}=window.jspdf; const doc=new jsPDF('l','mm','a4'); const f=fecha();
    doc.setFillColor(0,27,74); doc.rect(0,0,297,22,'F');
    doc.setTextColor(212,175,55); doc.setFontSize(13);
    doc.text(`PARTE POLICIAL · ${DEP_ACTUAL}`,14,10);
    doc.setTextColor(255,255,255); doc.setFontSize(9);
    doc.text(`Zona 8  |  Fecha: ${f}  |  Responsable: ${r.value}  |  Efectivo: ${REGS.length}`,14,17);
    doc.autoTable({
      startY:26,
      head:[['Grado','Nombres','Función','Novedades/Alertas','Gr','Estado']],
      body:REGS.map(p=>[p.grado,p.nombres,p.funcion,p.novedades,p.grupo,p.estado]),
      styles:{fontSize:7,cellPadding:1.5},
      headStyles:{fillColor:[1,42,107],textColor:[212,175,55]},
      alternateRowStyles:{fillColor:[240,243,250]}
    });
    doc.save(`Parte_${DEP_ACTUAL.replace(/\s+/g,'_')}_${f}.pdf`);
  });
}
